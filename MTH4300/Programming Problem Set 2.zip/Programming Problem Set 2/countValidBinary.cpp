/******************************************************************************
 countValidBinary.cpp
******************************************************************************
 Name:
******************************************************************************
 Collaborators/outside sources used
(IMPORTANT! Write "NONE" if none were used):



 Reminder: you are to write your own code.
******************************************************************************
 AI conversation links (if AI was used):



******************************************************************************
 Overall notes (not to replace inline comments):


*/

#include<iostream>

/* Complete the definition of the following function. The function should be recursive.
   Parameters: k, length of binary string (n), and ending digit, 0 or 1 (end)
   Returns: the number of k-separated binary strings of length n with ending digit end
*/
int kSeparated(int k, int n, int end){

}

// You can add a main function to test here but comment it out before submitting