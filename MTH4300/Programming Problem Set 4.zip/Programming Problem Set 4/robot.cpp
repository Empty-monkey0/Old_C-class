/******************************************************************************
 robot.cpp
******************************************************************************
 Name:
******************************************************************************
 Collaborators/outside sources used
(IMPORTANT! Write "NONE" if none were used):



 Reminder: you are to write your own code.
******************************************************************************
 AI conversation links:

 Step 2 (debugging tutor, if used):

 Step 3 (code review):

******************************************************************************
 Overall notes (not to replace inline comments):


*/

#include<iostream>
#include "robot.h" // write the class declaration in the header file; implement the methods here
// No global variables

#include <random>

// this file should not contain a main function, only the method implementations

// randrange() is a standalone helper function (not a class method).
// You can call it from your method implementations.
// returns a random integer between a and b inclusive, with each integer equally likely
int randrange(int a, int b){
    std::random_device rd; // Obtain a random number from hardware
    std::mt19937 eng(rd()); // Seed the generator
    std::uniform_int_distribution<> distr(a, b); // Define the range
    return distr(eng); // returns a random integer between a and b inclusive
}



