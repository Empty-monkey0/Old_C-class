/******************************************************************************
 robot.h
******************************************************************************
 Name:
******************************************************************************
 Collaborators/outside sources used
(IMPORTANT! Write "NONE" if none were used):



 Reminder: you are to write your own code.
******************************************************************************
 AI conversation links:

 Step 2 (debugging tutor, if used):

 Step 3 (code review):

******************************************************************************
 Overall notes (not to replace inline comments):


*/

#include<iostream> // no other headers should be added here

// this file should not contain a main function
// The Robogame class should be defined here (declarations only)



