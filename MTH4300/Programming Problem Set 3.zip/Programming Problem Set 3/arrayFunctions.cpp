/******************************************************************************
 arrayFunctions.cpp
******************************************************************************
 Name:
******************************************************************************
 Collaborators/outside sources used
(IMPORTANT! Write "NONE" if none were used):



 Reminder: you are to write your own code.
******************************************************************************
 AI conversation links:

 Step 2 (debugging tutor, if used):

 Step 3 (code review for intersection):

 Step 3 (code review for insert):

******************************************************************************
 Overall notes (not to replace inline comments):


*/

#include<iostream>

/* intersection
   Parameters: pointer to first array, its length, pointer to second array, its length
   Returns: the number of values that appear in both arrays
*/
int intersection(int* arr1, int len1, int* arr2, int len2){

}

/* insert
   Parameters: pointer to a pointer to a dynamically allocated array, the array's length,
               the value to insert, and the index at which to insert it
   Returns: nothing (modifies the array through the pointer-to-pointer)
*/
void insert(int** arrPtr, int length, int value, int index){

}

// You can add a main function to test here but remove it before submitting
