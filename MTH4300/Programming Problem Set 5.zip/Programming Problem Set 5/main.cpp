/******************************************************************************
 main.cpp
******************************************************************************
 Name:
******************************************************************************
 AI conversation links (Step 2 and/or Step 3):


******************************************************************************
 Overall notes (not to replace inline comments):


*/

// To compile and run locally:
//   g++ DynamicArray.cpp main.cpp -o main
//   ./main

#include<iostream>
#include "DynamicArray.h"


// ============================================================
// TESTER CODE — uncomment sections as you implement each part.
// For Part (c), delete this tester code and write your own main()
// following the instructions in the assignment.
// ============================================================

/*
int main()
{
    // --- Part (a): Core DynamicArray class ---

    DynamicArray d1;
    std::cout << "Size: " << d1.getSize() << std::endl;       // Expected: 0
    std::cout << "Capacity: " << d1.getCapacity() << std::endl; // Expected: 10

    DynamicArray d2(3);
    std::cout << "Size: " << d2.getSize() << std::endl;       // Expected: 0
    std::cout << "Capacity: " << d2.getCapacity() << std::endl; // Expected: 3

    d2.push_back(10);
    d2.push_back(20);
    d2.push_back(30);
    std::cout << "Size: " << d2.getSize() << std::endl;       // Expected: 3
    std::cout << "Capacity: " << d2.getCapacity() << std::endl; // Expected: 3
    d2.print();                                      // Expected: [10, 20, 30]

    d2.push_back(40);
    std::cout << "Size: " << d2.getSize() << std::endl;       // Expected: 4
    std::cout << "Capacity: " << d2.getCapacity() << std::endl; // Expected: 6
    d2.print();                                      // Expected: [10, 20, 30, 40]

    std::cout << d2.get(0) << std::endl;  // Expected: 10
    std::cout << d2.get(3) << std::endl;  // Expected: 40
    d2.get(10);                 // Expected: Error: index out of bounds
    d2.get(-1);                 // Expected: Error: index out of bounds

    d2.set(0, 99);
    d2.print();                 // Expected: [99, 20, 30, 40]
    d2.set(10, 5);              // Expected: Error: index out of bounds

    DynamicArray d3;
    d3.print();                 // Expected: []

    return 0;
}
*/
