/******************************************************************************
 DynamicArray.cpp
******************************************************************************
 Name:
******************************************************************************
 AI conversation links (Step 2 and/or Step 3):


******************************************************************************
 Overall notes (not to replace inline comments):


*/

#include "DynamicArray.h" // write the class declaration in the header file; implement the methods here
// No global variables

// this file should not contain a main function, only the method implementations

// Note: default parameter values go in the .h file only, not here.
// Reminder: when implementing methods here, use ClassName::methodName syntax.
// The class name goes after the return type, e.g.:
//   void DynamicArray::push_back(int val) { ... }


