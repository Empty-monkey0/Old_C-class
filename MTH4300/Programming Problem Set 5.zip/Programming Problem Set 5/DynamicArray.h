/******************************************************************************
 DynamicArray.h
******************************************************************************
 Name:
******************************************************************************
 AI conversation links (Step 2 and/or Step 3):


******************************************************************************
 Overall notes (not to replace inline comments):


*/

// Include guard: prevents this header from being included more than once
// during compilation (which would cause duplicate definition errors).
#ifndef DYNAMICARRAY_H
#define DYNAMICARRAY_H

#include<iostream> // no other headers should be added

// this file should not contain a main function
// The DynamicArray class should be defined here (declarations only)

class DynamicArray
{
    /* Write the class declaration */
};

#endif
